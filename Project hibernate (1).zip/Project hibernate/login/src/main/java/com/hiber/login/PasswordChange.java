package com.hiber.login;

import java.util.Scanner;

public class PasswordChange {
    public static void changePassword(UserDAO userDAO) {
        System.out.println("To change your password");
        Scanner scanner = new Scanner(System.in);
 
        System.out.print("Enter your username: ");
        String username = scanner.nextLine();
 
        if (!userDAO.verifyUser(username)) {
            System.out.println("No such user is present.");
            return;
        }
 
        String email = userDAO.getUserEmail(username);
 
        System.out.print("Enter the email code sent to your email: ");
        String emailCode = scanner.nextLine();
 
        if (userDAO.verifyEmailCode(email, emailCode)) {
            System.out.print("Enter your new password: ");
            String newPassword = scanner.nextLine();
 
            if (userDAO.updatePassword(username, newPassword)) {
                System.out.println("Password updated successfully.");
            } else {
                System.out.println("Failed to update the password.");
            }
        } else {
            System.out.println("Invalid email code. Please try again.");
        }
    }
}
