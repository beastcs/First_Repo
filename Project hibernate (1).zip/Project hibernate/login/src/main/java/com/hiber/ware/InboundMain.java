package com.hiber.ware;

import org.hibernate.Session;
import org.hibernate.Transaction;
 
import java.util.Scanner;
 
public class InboundMain {
 
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
            System.out.println("Inbound Requisition Form");
            System.out.print("Product Name: ");
            String productName = scanner.nextLine();
 
            System.out.print("Supplier Name: ");
            String supplierName = scanner.nextLine();
 
            System.out.print("Product Code: ");
            String productCode = scanner.nextLine();
 
            System.out.print("Supplier Location: ");
            String supplierLocation = scanner.nextLine();
 
            System.out.print("Batch no.: ");
            String batchNumber = scanner.nextLine();
 
            System.out.print("Purchase Order no.: ");
            String purchaseOrderNumber = scanner.nextLine();
 
            System.out.print("Product Dimensions: ");
            String productDimensions = scanner.nextLine();
 
            System.out.print("Date of PO Issuance: ");
            String dateOfPOIssuance = scanner.nextLine();
 
            System.out.print("Product Weight: ");
            String productWeight = scanner.nextLine();
 
            System.out.print("Date of Delivery: ");
            String dateOfDelivery = scanner.nextLine();
 
            System.out.print("Product Qty.: ");
            int productQty = scanner.nextInt();
 
            if (validateInboundRequisition(productName, supplierName, productCode, supplierLocation, batchNumber,
                    purchaseOrderNumber, productDimensions, dateOfPOIssuance, productWeight, dateOfDelivery, productQty)) {
                System.out.println("Form submitted successfully!");
            } else {
                System.out.println("Form validation failed. Place might be unavailable.");
            }
        }
 
    private static boolean validateInboundRequisition(String productName, String supplierName, String productCode,String supplierLocation, String batchNumber, String purchaseOrderNumber,String productDimensions, String dateOfPOIssuance, String productWeight,String dateOfDelivery, int productQty) {
        try {
            Session session = HibernateUtil.getSessionFactory().openSession();
            Transaction transaction = session.beginTransaction();
            InboundTable inboundRequisition = new InboundTable();
            inboundRequisition.setProductName(productName);
            inboundRequisition.setSupplierName(supplierName);
            inboundRequisition.setProductCode(productCode);
            inboundRequisition.setSupplierLocation(supplierLocation);
            inboundRequisition.setBatchNumber(batchNumber);
            inboundRequisition.setPurchaseOrderNumber(purchaseOrderNumber);
            inboundRequisition.setProductDimensions(productDimensions);
            inboundRequisition.setDateOfPOIssuance(dateOfPOIssuance);
            inboundRequisition.setProductWeight(productWeight);
            inboundRequisition.setDateOfDelivery(dateOfDelivery);
            inboundRequisition.setProductQty(productQty);
 
            session.save(inboundRequisition);
 
            transaction.commit();
 
            return true;
 
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}
