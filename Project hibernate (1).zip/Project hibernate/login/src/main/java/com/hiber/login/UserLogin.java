package com.hiber.login;

import java.util.Scanner;

public class UserLogin {
    public static void login(UserDAO userDAO) {
        System.out.println("User Login");
        Scanner scanner = new Scanner(System.in);
 
        System.out.print("Enter username: ");
        String username = scanner.nextLine();
 
        System.out.print("Enter password: ");
        String password = scanner.nextLine();
 
        if (userDAO.authenticateUser(username, password)) {
            System.out.println("Login successful. Welcome, " + username + "!");
            // Direct to homepage
        } else {
            System.out.println("Invalid username or password. Please try again.");
        }
    }
}