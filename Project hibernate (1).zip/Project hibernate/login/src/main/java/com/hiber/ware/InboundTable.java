package com.hiber.ware;

import javax.persistence.*;

@Entity
@Table(name = "InboundRequisition")
public class InboundTable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;
 
    @Column(name = "productName")
    private String productName;
 
    @Column(name = "supplierName")
    private String supplierName;
 
    @Column(name = "productCode")
    private String productCode;
 
    @Column(name = "supplierLocation")
    private String supplierLocation;
    
    @Column(name = "batchNumber")
    private String batchNumber;
    
    @Column(name = "purchaseOrderNumber")
    private String purchaseOrderNumber;
    
    @Column(name = "productDimensions")
    private String productDimensions;
    
    @Column(name = "dateOfPOIssuance")
    private String dateOfPOIssuance;
    
    @Column(name = "productWeight")
    private String productWeight;

    @Column(name = "dateOfDelivery")
    private String dateOfDelivery;
    
    @Column(name = "productQty")
    private int productQty;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getSupplierName() {
		return supplierName;
	}

	public void setSupplierName(String supplierName) {
		this.supplierName = supplierName;
	}

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public String getSupplierLocation() {
		return supplierLocation;
	}

	public void setSupplierLocation(String supplierLocation) {
		this.supplierLocation = supplierLocation;
	}

	public String getBatchNumber() {
		return batchNumber;
	}

	public void setBatchNumber(String batchNumber) {
		this.batchNumber = batchNumber;
	}

	public String getPurchaseOrderNumber() {
		return purchaseOrderNumber;
	}

	public void setPurchaseOrderNumber(String purchaseOrderNumber) {
		this.purchaseOrderNumber = purchaseOrderNumber;
	}

	public String getProductDimensions() {
		return productDimensions;
	}

	public void setProductDimensions(String productDimensions) {
		this.productDimensions = productDimensions;
	}

	public String getDateOfPOIssuance() {
		return dateOfPOIssuance;
	}

	public void setDateOfPOIssuance(String dateOfPOIssuance) {
		this.dateOfPOIssuance = dateOfPOIssuance;
	}

	public String getProductWeight() {
		return productWeight;
	}

	public void setProductWeight(String productWeight) {
		this.productWeight = productWeight;
	}

	public String getDateOfDelivery() {
		return dateOfDelivery;
	}

	public void setDateOfDelivery(String dateOfDelivery) {
		this.dateOfDelivery = dateOfDelivery;
	}

	public int getProductQty() {
		return productQty;
	}

	public void setProductQty(int productQty) {
		this.productQty = productQty;
	}
    
    
}