package com.hiber.login;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
 
import java.util.Scanner;
 
public class Main {
    public static void main(String[] args) {
        Configuration configuration = new Configuration().configure("proj.cfg.xml");
        try {
        	SessionFactory sessionFactory = configuration.buildSessionFactory();
            UserDAO userDAO = new UserDAO(sessionFactory);
 
            while (true) {
                int choice = displayMenuAndGetChoice();
 
                switch (choice) {
                    case 1:
                        UserLogin.login(userDAO);
                        break;
                    case 2:
                        UserRegistration.register(userDAO);
                        break;
                    case 3:
                        PasswordChange.changePassword(userDAO);
                        break;
                    case 4:
                        System.out.println("Exiting the application.");
                        System.exit(0);
                        break;
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            }
        }catch (Exception e) {
        	System.out.println(e);
        }
    }
 
    private static int displayMenuAndGetChoice() {
        System.out.println("Stock to ship");
        System.out.println("1. Login");
        System.out.println("2. Register");
        System.out.println("3. Change Password");
        System.out.println("4. Exit");
 
        System.out.print("Enter your choice: ");
        Scanner scanner = new Scanner(System.in);
 
        int choice = 0;
        try {
            choice = Integer.parseInt(scanner.nextLine());
        } catch (NumberFormatException e) {
            System.out.println("Invalid choice. Please enter a number.");
        }
 
        return choice;
    }
}