package com.hiber.login;

import java.util.Scanner;

public class UserRegistration {
    public static void register(UserDAO userDAO) {
        try {
            // Input from the user
            Scanner scanner = new Scanner(System.in);
            // Input values
            System.out.println("Username: ");
            String username = scanner.nextLine();
            System.out.println("Name: ");
            String name = scanner.nextLine();
            System.out.println("Password: ");
            String password = scanner.nextLine();
            System.out.println("EMPID: ");
            String employeeId = scanner.nextLine();
            System.out.println("Email: ");
            String email = scanner.nextLine();
 
            User user = new User();
            user.setUsername(username);
            user.setName(name);
            user.setPassword(password);
            user.setEmployeeId(employeeId);
            user.setEmail(email);
 
            userDAO.registerUser(user);
 
            System.out.println("User registered successfully.");
        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
        }
    }
}