package com.hiber.ware;

import org.hibernate.Session;
import org.hibernate.Transaction;
 
import javax.persistence.TypedQuery;
import java.util.Scanner;
 
public class OutboundMain {
 
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
            System.out.println("Outbound Requisition Form");
            System.out.print("Product Name: ");
            String productName = scanner.nextLine();
            System.out.print("Product Code: ");
            String productCode = scanner.nextLine();
            System.out.print("Delivery Department: ");
            String deliveryDepartment = scanner.nextLine();
 
            String departmentInCharge = validateOutboundRequisition(productName, productCode, deliveryDepartment);
 
            if (departmentInCharge != null) {
                System.out.println("Form submitted successfully!");
                System.out.println("Department In-Charge: " + departmentInCharge);
            } else {
                System.out.println("Form validation failed.");
            }
        }
 
    private static String validateOutboundRequisition(String productName, String productCode, String deliveryDepartment) {
        try  {
        	Session session = HibernateUtil.getSessionFactory().openSession();
            Transaction transaction = session.beginTransaction();
 
            OutboundTable outboundRequisition = new OutboundTable();
            outboundRequisition.setProductName(productName);
            outboundRequisition.setProductCode(productCode);
            outboundRequisition.setDeliveryDepartment(deliveryDepartment);
 
            session.save(outboundRequisition);
            transaction.commit();
 
            return getDepartmentInCharge(deliveryDepartment, session);
 
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
 
    private static String getDepartmentInCharge(String deliveryDepartment, Session session) {
        try {
            String hql = "SELECT o.deliveryDepartmentInCharge FROM OutboundTable o WHERE o.deliveryDepartment = :department";
            TypedQuery<String> query = session.createQuery(hql, String.class);
            query.setParameter("department", deliveryDepartment);
 
            return query.getSingleResult();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}