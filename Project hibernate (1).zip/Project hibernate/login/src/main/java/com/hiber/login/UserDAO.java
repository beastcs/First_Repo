package com.hiber.login;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
 
public class UserDAO {
    private final SessionFactory sessionFactory;
 
    public UserDAO(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }
 
    public void registerUser(User user) {
        	Session session = sessionFactory.openSession();
            Transaction transaction = session.beginTransaction();
            session.save(user);
            transaction.commit();
    }
 
    public boolean authenticateUser(String username, String password) {
        	Session session = sessionFactory.openSession();
            Query<Long> query = session.createQuery("SELECT COUNT(*) FROM User WHERE username = :username AND password = :password", Long.class);
            query.setParameter("username", username);
            query.setParameter("password", password);
            Long count = query.uniqueResult();
            return count != null && count > 0;
    }
 
    public boolean verifyUser(String username) {
        	Session session = sessionFactory.openSession();
            Query<Long> query = session.createQuery("SELECT COUNT(*) FROM User WHERE username = :username", Long.class);
            query.setParameter("username", username);
            Long count = query.uniqueResult();
            return count != null && count > 0;
    }
 
    public String getUserEmail(String username) {
        	Session session = sessionFactory.openSession();
            Query<String> query = session.createQuery("SELECT email FROM User WHERE username = :username", String.class);
            query.setParameter("username", username);
            return query.uniqueResult();
    }
 
    public boolean verifyEmailCode(String email, String emailCode) {
        // Implement logic to verify if the provided email code matches the one sent to the user's email
        return emailCode.equals("123456"); // Replace with actual code
    }
 
    public boolean updatePassword(String username, String newPassword) {
        	Session session = sessionFactory.openSession();
            Transaction transaction = session.beginTransaction();
            Query query = session.createQuery("UPDATE User SET password = :newPassword WHERE username = :username");
            query.setParameter("newPassword", newPassword);
            query.setParameter("username", username);
            int updatedEntities = query.executeUpdate();
            transaction.commit();
            return updatedEntities > 0;
    }
 
}
