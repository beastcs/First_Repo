package com.main.app.inventory.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import com.main.app.inventory.entity.Requisition;

public interface RequisitionRepository extends JpaRepository<Requisition, Long> {
    // You can add custom queries if needed
}
