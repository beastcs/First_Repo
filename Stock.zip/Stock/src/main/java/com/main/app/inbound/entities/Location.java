package com.main.app.inbound.entities;

import jakarta.persistence.*;

@Entity
public class Location {
    @Id
    private Integer locationId;
    private String locationDescription;
    private Integer statusCode;
    private Integer locationLength;
    private Integer locationWidth;
    private Integer locationHeight;
    private Long referenceProductCode;


    public Integer getLocationId() {
		return locationId;
	}

	public void setLocationId(Integer locationId) {
		this.locationId = locationId;
	}

	public String getLocationDescription() {
		return locationDescription;
	}

	public void setLocationDescription(String locationDescription) {
		this.locationDescription = locationDescription;
	}

	public Integer getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(Integer statusCode) {
		this.statusCode = statusCode;
	}

	public Integer getLocationLength() {
		return locationLength;
	}

	public void setLocationLength(Integer locationLength) {
		this.locationLength = locationLength;
	}

	public Integer getLocationWidth() {
		return locationWidth;
	}

	public void setLocationWidth(Integer locationWidth) {
		this.locationWidth = locationWidth;
	}

	public Integer getLocationHeight() {
		return locationHeight;
	}

	public void setLocationHeight(Integer locationHeight) {
		this.locationHeight = locationHeight;
	}

	public Long getReferenceProductCode() {
		return referenceProductCode;
	}

	public void setReferenceProductCode(Long referenceProductCode) {
		this.referenceProductCode = referenceProductCode;
	}

	public void updateStatusCodeAndReference(InboundProduct product) {
        if (fitsProduct(product)) {
            this.statusCode = 1;
        } else {
            this.statusCode = 0;
        }

        this.referenceProductCode = product.getProductCode();
    }

    public boolean fitsProduct(InboundProduct product) {
        int productVolume = product.getHeight() * product.getWidth() * product.getBreadth();
        int locationVolume = locationLength * locationWidth * locationHeight;

        return product.getHeight() <= locationLength &&
               product.getWidth() <= locationWidth &&
               product.getHeight() <= locationHeight &&
               productVolume <= locationVolume;
    }
}
