package com.main.app.inbound.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.main.app.inbound.entities.InboundProduct;
import com.main.app.inbound.entities.Location;
import com.main.app.inbound.repo.InboundProductRepository;
import com.main.app.inbound.repo.LocationRepository;

@Service
public class InboundService {

    @Autowired
    private LocationRepository locationRepository;
    
    @Autowired
    private InboundProductRepository productRepository;
    
    @Transactional
    public void processProduct(InboundProduct product, Location location) {
        if (location != null) {
            if (location.fitsProduct(product)) {
                location.updateStatusCodeAndReference(product);
                locationRepository.updateStatusCode(product.getProductCode(), location.getStatusCode());
            } else {
                throw new IllegalArgumentException("The product does not fit the location criteria.");
            }
        } else {
            throw new IllegalArgumentException("Location cannot be null.");
        }
    }
    
    public InboundProduct getInboundProductByCode(long productCode) {
        return productRepository.findByProductCode(productCode);
    }
    
    public List<Location> getLocationStatus() {
    	return locationRepository.findAll();
    }
}
