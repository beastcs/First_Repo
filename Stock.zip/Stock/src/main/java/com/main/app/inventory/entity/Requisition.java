package com.main.app.inventory.entity;

import jakarta.persistence.*;

@Entity
public class Requisition {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String requisitionerDepartment;
    private String uniqueItemCode;
    private int quantity;
    private String purposeOfRequisition;
    private String materialRequired;
    private String dateOfRequisition;
    private String itemDescription;
    private String unitOfMeasure;
    private String deliveryDepartment;
    private String notesAndComments;
    
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getRequisitionerDepartment() {
		return requisitionerDepartment;
	}
	public void setRequisitionerDepartment(String requisitionerDepartment) {
		this.requisitionerDepartment = requisitionerDepartment;
	}
	public String getUniqueItemCode() {
		return uniqueItemCode;
	}
	public void setUniqueItemCode(String uniqueItemCode) {
		this.uniqueItemCode = uniqueItemCode;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public String getPurposeOfRequisition() {
		return purposeOfRequisition;
	}
	public void setPurposeOfRequisition(String purposeOfRequisition) {
		this.purposeOfRequisition = purposeOfRequisition;
	}
	public String getMaterialRequired() {
		return materialRequired;
	}
	public void setMaterialRequired(String materialRequired) {
		this.materialRequired = materialRequired;
	}
	public String getDateOfRequisition() {
		return dateOfRequisition;
	}
	public void setDateOfRequisition(String dateOfRequisition) {
		this.dateOfRequisition = dateOfRequisition;
	}
	public String getItemDescription() {
		return itemDescription;
	}
	public void setItemDescription(String itemDescription) {
		this.itemDescription = itemDescription;
	}
	public String getUnitOfMeasure() {
		return unitOfMeasure;
	}
	public void setUnitOfMeasure(String unitOfMeasure) {
		this.unitOfMeasure = unitOfMeasure;
	}
	public String getDeliveryDepartment() {
		return deliveryDepartment;
	}
	public void setDeliveryDepartment(String deliveryDepartment) {
		this.deliveryDepartment = deliveryDepartment;
	}
	public String getNotesAndComments() {
		return notesAndComments;
	}
	public void setNotesAndComments(String notesAndComments) {
		this.notesAndComments = notesAndComments;
	}


}

