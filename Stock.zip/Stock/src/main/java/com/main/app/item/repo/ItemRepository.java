package com.main.app.item.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import com.main.app.item.entity.Item;

public interface ItemRepository extends JpaRepository<Item, Long> {
}