package com.main.app.login.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import com.main.app.login.entity.User_tab;

public interface UserRepository extends JpaRepository<User_tab, String> {
}
