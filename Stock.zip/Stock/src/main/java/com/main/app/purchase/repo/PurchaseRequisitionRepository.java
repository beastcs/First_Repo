package com.main.app.purchase.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import com.main.app.purchase.entities.PurchaseRequisition;

public interface PurchaseRequisitionRepository extends JpaRepository<PurchaseRequisition, Long> {
}
