package com.main.app.bom.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.main.app.bom.entity.InventoryItem;
import com.main.app.bom.repo.InventoryItemRepository;

@Service
public class InventoryItemService {
    private final InventoryItemRepository repository;

    @Autowired
    public InventoryItemService(InventoryItemRepository repository) {
        this.repository = repository;
    }

    public InventoryItem saveInventoryItem(InventoryItem inventoryItem) {
        return repository.save(inventoryItem);
    }
    
    public List<InventoryItem> getAll(){
    	return repository.findAll();
    }
}

