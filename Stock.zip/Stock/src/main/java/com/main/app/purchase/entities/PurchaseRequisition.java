package com.main.app.purchase.entities;

import jakarta.persistence.*;

@Entity
public class PurchaseRequisition {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String itemCode;
    private String quantity;
    private String departmentSelection;
    private String orderMaxQuantity;
    private String purpose;
    private String units;
    private String companyMake;
    private String approvalStatus;
    
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getItemCode() {
		return itemCode;
	}
	public void setItemCode(String itemCode) {
		this.itemCode = itemCode;
	}
	public String getQuantity() {
		return quantity;
	}
	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}
	public String getDepartmentSelection() {
		return departmentSelection;
	}
	public void setDepartmentSelection(String departmentSelection) {
		this.departmentSelection = departmentSelection;
	}
	public String getOrderMaxQuantity() {
		return orderMaxQuantity;
	}
	public void setOrderMaxQuantity(String orderMaxQuantity) {
		this.orderMaxQuantity = orderMaxQuantity;
	}
	public String getPurpose() {
		return purpose;
	}
	public void setPurpose(String purpose) {
		this.purpose = purpose;
	}
	public String getUnits() {
		return units;
	}
	public void setUnits(String units) {
		this.units = units;
	}
	public String getCompanyMake() {
		return companyMake;
	}
	public void setCompanyMake(String companyMake) {
		this.companyMake = companyMake;
	}
	public String getApprovalStatus() {
		return approvalStatus;
	}
	public void setApprovalStatus(String approvalStatus) {
		this.approvalStatus = approvalStatus;
	}

    
}
