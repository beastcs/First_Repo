package com.main.app.blanking.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import com.main.app.blanking.entity.Qc;

public interface QcRepo extends JpaRepository<Qc, Long> {
}