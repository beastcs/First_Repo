package com.main.app.bom.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import com.main.app.bom.entity.InventoryItem;

public interface InventoryItemRepository extends JpaRepository<InventoryItem, Long> {
}