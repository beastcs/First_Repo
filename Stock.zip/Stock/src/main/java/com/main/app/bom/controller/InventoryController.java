package com.main.app.bom.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.main.app.bom.entity.InventoryItem;
import com.main.app.bom.service.InventoryItemService;
import com.main.app.purchase.entities.PurchaseRequisition;

@RestController
@RequestMapping("/bom")
public class InventoryController {
    private final InventoryItemService inventoryItemService;

    @Autowired
    public InventoryController(InventoryItemService inventoryItemService) {
        this.inventoryItemService = inventoryItemService;
    }
    
    @GetMapping("/all")
    public List<InventoryItem> getAllBom() {
        return inventoryItemService.getAll();
    }
    
    @PostMapping("/addItem")
    public InventoryItem addInventoryItem(@RequestBody InventoryItem inventoryItem) {
        return inventoryItemService.saveInventoryItem(inventoryItem);
    }

}

