package com.main.app.inbound.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.main.app.inbound.entities.InboundProduct;
import com.main.app.inbound.entities.Location;
import com.main.app.inbound.repo.InboundProductRepository;
import com.main.app.inbound.repo.LocationRepository;
import com.main.app.inbound.service.InboundService;
import java.util.List;

@RestController
@RequestMapping("/inbound-products")
public class InboundProductController {

    @Autowired
    private InboundProductRepository productRepository;

    @Autowired
    private LocationRepository locationRepository;

    private final InboundService productService;

    public InboundProductController(InboundService productService) {
        this.productService = productService;
    }
    
    @GetMapping("/bycode/{productCode}")
    public ResponseEntity<InboundProduct> getInboundProductByCode(@PathVariable long productCode) {

        InboundProduct inboundProduct = productService.getInboundProductByCode(productCode);

        if (inboundProduct != null) {
            return ResponseEntity.ok(inboundProduct);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @GetMapping("/allproducts")
    public List<InboundProduct> getAllInboundProducts() {
        return productRepository.findAll();
    }

    @PostMapping("/inbound")
    public InboundProduct createInboundProduct(@RequestBody InboundProduct inboundProduct) {
        return productRepository.save(inboundProduct);
    }

    @PostMapping("/process/{inboundProductId}/{locationId}")
    public void processProduct(
    	    @PathVariable Long inboundProductId,
    	    @PathVariable Integer locationId
    	) {
    	    if (inboundProductId == null || locationId == null) {
    	        return;
    	    }

    	    InboundProduct inboundProduct = productRepository.findById(inboundProductId).orElse(null);
    	    Location location = locationRepository.findById(locationId).orElse(null);

    	    if (inboundProduct == null || location == null) {
    	        return;
    	    }

    	    productService.processProduct(inboundProduct, location);
    	}
}
