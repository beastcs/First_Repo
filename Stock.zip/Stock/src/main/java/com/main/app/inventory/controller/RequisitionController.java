package com.main.app.inventory.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.main.app.inventory.entity.Requisition;
import com.main.app.inventory.repo.RequisitionRepository;

import java.util.List;

@RestController
@RequestMapping("/requisitions")
public class RequisitionController {

    @Autowired
    private RequisitionRepository requisitionRepository;

    @GetMapping("/get")
    public List<Requisition> getAllRequisitions() {
        return requisitionRepository.findAll();
    }

    @PostMapping("/post")
    public Requisition createRequisition(@RequestBody Requisition requisition) {
        return requisitionRepository.save(requisition);
    }

}
