package com.main.app.bom.entity;

import jakarta.persistence.*;

@Entity
public class InventoryItem {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String uniqueItemCode;
    private String description;
    private int quantity;
    private String manufacturer;
    private String dimensions;
    private String supplierCode;
    private String unitOfMeasurement;
    private String subAssembly;
    private String notesAndComments;
    
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getUniqueItemCode() {
		return uniqueItemCode;
	}
	public void setUniqueItemCode(String uniqueItemCode) {
		this.uniqueItemCode = uniqueItemCode;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public String getManufacturer() {
		return manufacturer;
	}
	public void setManufacturer(String manufacturer) {
		this.manufacturer = manufacturer;
	}
	public String getDimensions() {
		return dimensions;
	}
	public void setDimensions(String dimensions) {
		this.dimensions = dimensions;
	}
	public String getSupplierCode() {
		return supplierCode;
	}
	public void setSupplierCode(String supplierCode) {
		this.supplierCode = supplierCode;
	}
	public String getUnitOfMeasurement() {
		return unitOfMeasurement;
	}
	public void setUnitOfMeasurement(String unitOfMeasurement) {
		this.unitOfMeasurement = unitOfMeasurement;
	}
	public String getSubAssembly() {
		return subAssembly;
	}
	public void setSubAssembly(String subAssembly) {
		this.subAssembly = subAssembly;
	}
	public String getNotesAndComments() {
		return notesAndComments;
	}
	public void setNotesAndComments(String notesAndComments) {
		this.notesAndComments = notesAndComments;
	}

    
}