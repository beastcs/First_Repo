package com.main.app.purchase.controller;

import com.main.app.purchase.entities.PurchaseRequisition;
import com.main.app.purchase.service.PurchaseRequisitionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/purchase-requisition")
public class PurchaseRequisitionController {

    private final PurchaseRequisitionService service;

    @Autowired
    public PurchaseRequisitionController(PurchaseRequisitionService service) {
        this.service = service;
    }

    @GetMapping("/all")
    public List<PurchaseRequisition> getAllPurchaseRequisitions() {
        return service.getAllPurchaseRequisitions();
    }

    @PostMapping("/submit")
    public void submitForm(@RequestBody PurchaseRequisition requisition) {
        service.savePurchaseRequisition(requisition);
    }
}
