package com.main.app.inbound.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import com.main.app.inbound.entities.Location;

public interface LocationRepository extends JpaRepository<Location, Integer> {
	
	 @Modifying
	 @Query("UPDATE Location l SET l.statusCode = :statusCode WHERE l.referenceProductCode = :productCode")
	 void updateStatusCode(@Param("productCode") Long productCode, @Param("statusCode") Integer statusCode);
;

}

