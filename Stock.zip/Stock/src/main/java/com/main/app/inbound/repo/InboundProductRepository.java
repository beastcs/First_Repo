package com.main.app.inbound.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.main.app.inbound.entities.InboundProduct;


public interface InboundProductRepository extends JpaRepository<InboundProduct, Long> {

	InboundProduct findByProductCode(long productCode);
}
