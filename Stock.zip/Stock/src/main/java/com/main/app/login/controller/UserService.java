package com.main.app.login.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.main.app.login.entity.User_tab;
import com.main.app.login.repo.UserRepository;
import java.util.List;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    public List<User_tab> getAllUsers() {
        return userRepository.findAll();
    }

    public User_tab getUserByUsername(String username) {
        return userRepository.findById(username).orElse(null);
    }

    public void saveUser(User_tab user) {
        userRepository.save(user);
    }

    public void deleteUser(String username) {
        userRepository.deleteById(username);
    }
}
