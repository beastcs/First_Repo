	package com.main.app.login.controller;
	
	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.web.bind.annotation.*;
	import com.main.app.login.entity.User_tab;
	import java.util.List;
	
	@RestController
	@RequestMapping("/login")
	@CrossOrigin(origins = "http://localhost:4200")
	public class UserController {
	
	    @Autowired
	    private UserService userService;
	
	    @GetMapping("/list")
	    public List<User_tab> getAllUsers() {
	        return userService.getAllUsers();
	    }
	
	    @GetMapping("/find/{username}")
	    public User_tab getUser(@PathVariable String username) {
	        return userService.getUserByUsername(username);
	    }
	
	    @PostMapping("/adduser")
	    public void addUser(@RequestBody User_tab user) {
	        userService.saveUser(user);
	    }
	
	}
