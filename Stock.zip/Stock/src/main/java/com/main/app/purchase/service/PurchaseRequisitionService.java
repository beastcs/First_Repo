package com.main.app.purchase.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.main.app.purchase.entities.PurchaseRequisition;
import com.main.app.purchase.repo.PurchaseRequisitionRepository;

@Service
public class PurchaseRequisitionService {
    private final PurchaseRequisitionRepository repository;

    @Autowired
    public PurchaseRequisitionService(PurchaseRequisitionRepository repository) {
        this.repository = repository;
    }

    public PurchaseRequisition savePurchaseRequisition(PurchaseRequisition requisition) {
        return repository.save(requisition);
    }

    public List<PurchaseRequisition> getAllPurchaseRequisitions() {
        return repository.findAll();
    }
}
