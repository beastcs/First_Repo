package com.main.app.blanking.entity;

import jakarta.persistence.*;

@Entity
@Table (name = "blanking")
public class QualityControl {

    @Id
    private String productCode;

    private int sampleSize;

    private float sheetMetalThicknessSample1;
    private float sheetMetalThicknessSample2;
    private float sheetMetalThicknessSample3;

    private String lubricationConditionSample1;
    private String lubricationConditionSample2;
    private String lubricationConditionSample3;

    private String sheetMetalStrengthSample1;
    private String sheetMetalStrengthSample2;
    private String sheetMetalStrengthSample3;

    private String toolGeometryDieSample1;
    private String toolGeometryDieSample2;
    private String toolGeometryDieSample3;

    private String toolGeometryPunchSample1;
    private String toolGeometryPunchSample2;
    private String toolGeometryPunchSample3;

    private String punchPressureSample1;
    private String punchPressureSample2;
    private String punchPressureSample3;

    private String punchSpeedSample1;
    private String punchSpeedSample2;
    private String punchSpeedSample3;
    
    
	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	public int getSampleSize() {
		return sampleSize;
	}
	public void setSampleSize(int sampleSize) {
		this.sampleSize = sampleSize;
	}
	public float getSheetMetalThicknessSample1() {
		return sheetMetalThicknessSample1;
	}
	public void setSheetMetalThicknessSample1(float sheetMetalThicknessSample1) {
		this.sheetMetalThicknessSample1 = sheetMetalThicknessSample1;
	}
	public float getSheetMetalThicknessSample2() {
		return sheetMetalThicknessSample2;
	}
	public void setSheetMetalThicknessSample2(float sheetMetalThicknessSample2) {
		this.sheetMetalThicknessSample2 = sheetMetalThicknessSample2;
	}
	public float getSheetMetalThicknessSample3() {
		return sheetMetalThicknessSample3;
	}
	public void setSheetMetalThicknessSample3(float sheetMetalThicknessSample3) {
		this.sheetMetalThicknessSample3 = sheetMetalThicknessSample3;
	}
	public String getLubricationConditionSample1() {
		return lubricationConditionSample1;
	}
	public void setLubricationConditionSample1(String lubricationConditionSample1) {
		this.lubricationConditionSample1 = lubricationConditionSample1;
	}
	public String getLubricationConditionSample2() {
		return lubricationConditionSample2;
	}
	public void setLubricationConditionSample2(String lubricationConditionSample2) {
		this.lubricationConditionSample2 = lubricationConditionSample2;
	}
	public String getLubricationConditionSample3() {
		return lubricationConditionSample3;
	}
	public void setLubricationConditionSample3(String lubricationConditionSample3) {
		this.lubricationConditionSample3 = lubricationConditionSample3;
	}
	public String getSheetMetalStrengthSample1() {
		return sheetMetalStrengthSample1;
	}
	public void setSheetMetalStrengthSample1(String sheetMetalStrengthSample1) {
		this.sheetMetalStrengthSample1 = sheetMetalStrengthSample1;
	}
	public String getSheetMetalStrengthSample2() {
		return sheetMetalStrengthSample2;
	}
	public void setSheetMetalStrengthSample2(String sheetMetalStrengthSample2) {
		this.sheetMetalStrengthSample2 = sheetMetalStrengthSample2;
	}
	public String getSheetMetalStrengthSample3() {
		return sheetMetalStrengthSample3;
	}
	public void setSheetMetalStrengthSample3(String sheetMetalStrengthSample3) {
		this.sheetMetalStrengthSample3 = sheetMetalStrengthSample3;
	}
	public String getToolGeometryDieSample1() {
		return toolGeometryDieSample1;
	}
	public void setToolGeometryDieSample1(String toolGeometryDieSample1) {
		this.toolGeometryDieSample1 = toolGeometryDieSample1;
	}
	public String getToolGeometryDieSample2() {
		return toolGeometryDieSample2;
	}
	public void setToolGeometryDieSample2(String toolGeometryDieSample2) {
		this.toolGeometryDieSample2 = toolGeometryDieSample2;
	}
	public String getToolGeometryDieSample3() {
		return toolGeometryDieSample3;
	}
	public void setToolGeometryDieSample3(String toolGeometryDieSample3) {
		this.toolGeometryDieSample3 = toolGeometryDieSample3;
	}
	public String getToolGeometryPunchSample1() {
		return toolGeometryPunchSample1;
	}
	public void setToolGeometryPunchSample1(String toolGeometryPunchSample1) {
		this.toolGeometryPunchSample1 = toolGeometryPunchSample1;
	}
	public String getToolGeometryPunchSample2() {
		return toolGeometryPunchSample2;
	}
	public void setToolGeometryPunchSample2(String toolGeometryPunchSample2) {
		this.toolGeometryPunchSample2 = toolGeometryPunchSample2;
	}
	public String getToolGeometryPunchSample3() {
		return toolGeometryPunchSample3;
	}
	public void setToolGeometryPunchSample3(String toolGeometryPunchSample3) {
		this.toolGeometryPunchSample3 = toolGeometryPunchSample3;
	}
	public String getPunchPressureSample1() {
		return punchPressureSample1;
	}
	public void setPunchPressureSample1(String punchPressureSample1) {
		this.punchPressureSample1 = punchPressureSample1;
	}
	public String getPunchPressureSample2() {
		return punchPressureSample2;
	}
	public void setPunchPressureSample2(String punchPressureSample2) {
		this.punchPressureSample2 = punchPressureSample2;
	}
	public String getPunchPressureSample3() {
		return punchPressureSample3;
	}
	public void setPunchPressureSample3(String punchPressureSample3) {
		this.punchPressureSample3 = punchPressureSample3;
	}
	public String getPunchSpeedSample1() {
		return punchSpeedSample1;
	}
	public void setPunchSpeedSample1(String punchSpeedSample1) {
		this.punchSpeedSample1 = punchSpeedSample1;
	}
	public String getPunchSpeedSample2() {
		return punchSpeedSample2;
	}
	public void setPunchSpeedSample2(String punchSpeedSample2) {
		this.punchSpeedSample2 = punchSpeedSample2;
	}
	public String getPunchSpeedSample3() {
		return punchSpeedSample3;
	}
	public void setPunchSpeedSample3(String punchSpeedSample3) {
		this.punchSpeedSample3 = punchSpeedSample3;
	}

    

}
