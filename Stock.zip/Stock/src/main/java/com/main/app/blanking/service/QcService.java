package com.main.app.blanking.service;

import org.springframework.stereotype.Service;
import com.main.app.blanking.entity.Qc;
import com.main.app.blanking.repo.QcRepo;

@Service
public class QcService {
    private final QcRepo qcRepository;

    public QcService(QcRepo qcRepository) {
        this.qcRepository = qcRepository;
    }

    public Qc saveQc(Qc qc) {
        return qcRepository.save(qc);
    }
}