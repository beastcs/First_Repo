package com.main.app.blanking.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.main.app.blanking.entity.QualityControl;
import com.main.app.blanking.repo.QualityControlRepository;

@RestController
@RequestMapping("/quality-control")
public class QualityControlController {

    @Autowired
    private QualityControlRepository qualityControlRepository;

    @PostMapping("/save")
    public QualityControl saveQualityControl(@RequestBody QualityControl qualityControl) {
        return qualityControlRepository.save(qualityControl);
    }

}

