package com.main.app.blanking.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import com.main.app.blanking.entity.QualityControl;

public interface QualityControlRepository extends JpaRepository<QualityControl, String> {
}
