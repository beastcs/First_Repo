package com.main.app.blanking.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.main.app.blanking.entity.Qc;
import com.main.app.blanking.service.QcService;

@RestController
@RequestMapping("/quality")
public class QcController {
	
	@Autowired
    private final QcService qcService;

    public QcController(QcService qcService) {
        this.qcService = qcService;
    }

    @PostMapping("/save")
    public Qc saveQc(@RequestBody Qc qc) {
        return qcService.saveQc(qc);
    }
}